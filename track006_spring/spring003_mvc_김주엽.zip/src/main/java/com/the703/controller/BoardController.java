package com.the703.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.the703.dto.BoardDto;
import com.the703.service.BoardService;

@Controller
public class BoardController {
	@Autowired BoardService service;
	
	
	// �� ��Ʈ���� db�� �ʿ��Ѱ��� �������� ������
	
	// 1. ��ü ����Ʈ
	@RequestMapping("/board/list.do")
	public String list(Model model) {
		model.addAttribute("list", service.selectAll()); // ������ �Ѱ��ֱ�
		return "board/list";
	}
	// /view/ + board/list + .jsp
	//http://localhost:8080/spring003_mvc/board/list.do
	
	// 2-1. �� ������ ���
	@RequestMapping( value = "/board/write.do", method = RequestMethod.GET )
	public String write() {
		return "board/write";
	}
	//http://localhost:8080/spring003_mvc/board/write.do
	
	// 2-2. �۾��� ���
	@RequestMapping( value = "/board/write.do", method = RequestMethod.POST )
	public String write_post(BoardDto dto, RedirectAttributes rttr) {
		String result = "�۾��� ����";
		if(service.insert(dto) > 0) { result = "�۾��� ����"; }
		rttr.addFlashAttribute("result",result); // Flash - �ѹ��� ����
		return "redirect:/board/list.do"; // response.sendRedirect + alert ó�����ȵ�
	}
	
	// 3. �� �󼼺���
	@RequestMapping("/board/detail.do")
	public String detail(int bno, Model model) {
		model.addAttribute("dto", service.detail(bno));
		return "board/detail";
	}
	//http://localhost:8080/spring003_mvc/board/detail.do
	
	// 4-1. �� ������ ���
	@RequestMapping( value = "/board/edit.do", method = RequestMethod.GET)
	public String edit(int bno, Model model) {
//		String result = "�� ���� ����";
//		BoardDto dto = service.editView(bno);
//		if(service.edit(dto) > 0) {
//			result = "�� ���� ����";
//			model.addAttribute("dto",service.editView(bno));
//			return "board/edit";
//		}
//		else {
//			model.addAttribute("result", result);
//			return "board/detail?bno="+bno;
//		}
//			
//		String result = "��й�ȣ Ȯ��";
//		BoardDto dto = service.editView(bno);
//		if(service.passCheck(dto) > 0) {
//			model.addAttribute("dto", service.editView(bno));
//			return "board/edit";
//		}
//		else {
//			rttr.addFlashAttribute("result", result);
//			rttr.addAttribute("bno",dto.getBno());
//			return "redirect:/board/detail.do";
//		}
		model.addAttribute("dto", service.editView(bno));
	    return "board/edit";
		
	}
	//http://localhost:8080/spring003_mvc/board/edit.do
	
	// 4-2. �� ���� ���
	@RequestMapping( value = "/board/edit.do", method = RequestMethod.POST)
	public String edit_post(BoardDto dto, RedirectAttributes rttr) {
		String result = "��й�ȣ Ȯ��";
		if(service.edit(dto) > 0) {
			result = "�� ���� ����";
			rttr.addFlashAttribute("result",result);
			rttr.addAttribute("bno", dto.getBno());
			return "redirect:/board/edit.do?bno="+dto.getBno();
			}
		else {
			rttr.addFlashAttribute("result",result);
			rttr.addAttribute("bno", dto.getBno());
			return "redirect:/board/edit.do?bno="+dto.getBno();
		}
	}
	
	// 5. �� ������ ���
	@RequestMapping( value = "/board/delete.do", method = RequestMethod.GET)
	public String delete(int bno, Model model) {
		model.addAttribute("dto", service.editView(bno));
		return "board/delete";
	}
	
	@RequestMapping( value = "/board/delete.do", method = RequestMethod.POST)
	public String delete_post(BoardDto dto, RedirectAttributes rttr) {
		String result = "�� ���� ����";
		if(service.delete(dto) > 0) {
			result = "�� ���� ����";
			rttr.addFlashAttribute("result",result);
			return "redirect:/board/list.do";
		}
		else {
			rttr.addFlashAttribute("result",result);
			rttr.addAttribute("bno", dto.getBno());
			return "redirect:/board/delete.do?bno="+dto.getBno();
		}
	}
	//http://localhost:8080/spring003_mvc/board/delete.do
	
}
