package ex02;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.the703.dao.BoardMapper;
import com.the703.dao.TestMapper;
import com.the703.dto.BoardDto;
import com.the703.service.BoardServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class) // 1. spring ���� �׽�Ʈ
@ContextConfiguration(locations = "classpath:config/root-context.xml") // 2. ����

public class BoardTest001 {
	@Autowired ApplicationContext context; // 3. Bean (�������� �����ϴ� ��ü) ����~�Ҹ�
	@Autowired DataSource dataSource;
	@Autowired SqlSession sqlSession;
	@Autowired TestMapper testMapper;
	@Autowired BoardMapper board;
	@Autowired BoardServiceImpl service; 
	
	@Ignore
	public void test1() {
		System.out.println(context);
		System.out.println(dataSource);
		System.out.println(sqlSession);
		System.out.println(testMapper.now());
	}
	
	@Ignore
	public void test2() throws UnknownHostException {
		BoardDto boardDto = new BoardDto();
		
		// delete
//		board.delete(2);
		
		// update
//		boardDto.setBno(1);
//		boardDto.setBtitle("bbb");
//		boardDto.setBcontent("bbb");
//		board.update(boardDto);
		
		// select
		System.out.println(board.select(1));
		
		// insert
//		boardDto.setBname("aaa");
//		boardDto.setBpass("aaa");
//		boardDto.setBtitle("aaa");
//		boardDto.setBcontent("aaa");
//		boardDto.setBip(InetAddress.getLocalHost().getHostAddress());
//		board.insert(boardDto);
		
		// selectAll
		System.out.println(board.selectAll());
	}
	
	@Ignore
	public void test3() {
		
		// ����
//		BoardDto dto = new BoardDto();
//		dto.setBno(4);
//		System.out.println(service.delete(dto));
		
		// ����
//		BoardDto dto = new BoardDto();
//		dto.setBno(4);
//		dto.setBname("ccc");
//		dto.setBpass("ccc");
//		dto.setBtitle("ddd");
//		dto.setBcontent("ddd");
//		System.out.println(service.edit(dto));
		
		// �󼼺���, ������ / �˻�
//		System.out.println(service.detail(4));
//		System.out.println(service.editView(4));
		
		// ����
//		BoardDto dto = new BoardDto();
//		dto.setBname("ccc");
//		dto.setBpass("ccc");
//		dto.setBtitle("ccc");
//		dto.setBcontent("ccc");
//		System.out.println(service.insert(dto));
		
		// ��ü ����Ʈ
		service.selectAll();
	}
}
